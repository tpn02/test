# TAWKTO MODULE FOR DOLIBARR ERP/CRM

## Features
Add a chat box to communicate with a support center (using TawkTo)

### For support providers
Create an account on TawkTo.io and insert your TawkTo ID into your customer Dolibarr setup so your customers can interact with you from their Dolibarr.

### For Dolibarr users
Enter your support provider ID into module setup to make the bubble picto appears on right top of your screen.
Just click on it to show the Chat box and communicate in real time, when you need, with your support provider.
If your support provider is not available, you can still send him your message by email. 

![Screenshot patient card](img/tawkto_screenshot.png?raw=true "Tawkto chat")

